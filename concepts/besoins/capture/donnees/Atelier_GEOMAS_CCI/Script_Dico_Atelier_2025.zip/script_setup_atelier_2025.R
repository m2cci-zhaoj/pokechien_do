## =============================================================================

## Atelier Intégration M2 GEOMAS CCI

## READ-ME 

## 2025-02-21
## Script de mise en route pour l'intégration des jeux de données de base 
## fournis : mesure_gps, move et stop

## PACKAGES R à installer - 

## data.table (pour utiliser fread) sinon utiliser read.csv()
## dplyr
## DBI
## RPostgres

## Script construit et testé avec cette configuration - 

## Windows 11
## R version 4.3.3 Angle Food Cake 2024-02-29
## postgresql 14.10
## postgis 3.4

## Objectifs -

## 1-On passe par un environnement R afin d'appeler les jeux de données fournis 
## vu que les imports directs de CSV dans pgadmin sont hasardeux
## 2-On envoie les requêtes de création des structures des 3 tables postgresql depuis R
## 3-On envoie les données dans les 3 tables
## 4-On envoie les requêtes de modification de la composante géométrique des tables.

## IMPORTANT -
## Votre base de données postgre/postgis devra être créée en amont dans postgresql.
## Ici, elle est nommée "atelier".

## IMPORTANT 2 -
## Le système de coordonnées des données spatiales est le Lambert 93, de code 2154.
## Ils sont convertis en fin de script en envoyant directement une requête dans la BD depuis R.

## Les timestamps sont capturés en UTC. R les chargera bien en UTC mais il est fort 
## probable que, lors de l'écriture des données vers PostgreSQL, ils soient convertis 
## vers la timezone locale utilisée par l'interface PostgreSQL. 
## il faudra le vérifier de votre côté a posteriori ...
## =============================================================================

# Init. ----
{
  remove(list=ls())
  
  ## charger les packages
  library(data.table)
  library(DBI)
  library(RPostgres)
  
  ## Charger les données CSV
  ## Chemins à adapter à votre configuration !
  mesure_gps = fread("DATA/mesure_gps_2025.csv")
  move_mbgp = fread("DATA/move_mbgp_2025.csv")
  stop_mbgp = fread("DATA/stop_mbgp_2025.csv")
  
}

# 1-Etablir la connexion à la base de données postgresql ----

## Vérifier si la connexion peut être établie 
dbCanConnect(
  RPostgres::Postgres(),
  dbname = "atelier", #à adapter au nom de votre DB
  port = 5432, #à adapter si nécessaire
  user = "postgres", #à adapter
  password = "postgres" #à adapter
) #si TRUE alors la connexion peut être créée

{
  ## Etablir la connexion à la DB
  ## Le nom de la connexion sera pg_con
  pg_con = dbConnect(
    RPostgres::Postgres(),
    dbname = "atelier", #adapter au nom de votre DB créée
    port = 5432,  #à adapter si besoin
    user = "postgres", #idem
    password = "postgres" #idem
  )
  
  ## Lister les tables existantes
  dbListTables(pg_con)
  
  ## Voir les champs d'une table donnée 
  dbListFields(pg_con, "geometry_columns") #nom de la table toujours entre guillemets
}

# 2-Créer la structure des trois tables ----

## On fait exécuter depuis r des requêtes de type CREATE TABLE
{
  ## Structure de la table mesure_gps
  DBI::dbSendQuery(
    pg_con, 
    "CREATE TABLE mesure_gps (
    i_pid INTEGER NOT NULL,
    i_id_pers INTEGER NOT NULL,
    i_id_session INTEGER NOT NULL,
    dt_date_utc TIMESTAMP WITH TIME ZONE,
    r_lat FLOAT,
    r_lon FLOAT,
    geometry GEOMETRY,
    CONSTRAINT pk_pointsgps PRIMARY KEY (i_pid)
    );"
  )
  
  ## Structure de la table move
  DBI::dbSendQuery(
    pg_con, 
    "CREATE TABLE move (
    i_move_id INTEGER NOT NULL,
    i_pid_start INTEGER NOT NULL,
    i_pid_end INTEGER NOT NULL,
    geometry GEOMETRY,
    CONSTRAINT pk_move PRIMARY KEY (i_move_id)
    );"
  )
  
  ## Structure de la table stop
  DBI::dbSendQuery(
    pg_con, 
    "CREATE TABLE stop (
    i_stop_id INTEGER NOT NULL,
    i_pid_start INTEGER NOT NULL,
    i_pid_end INTEGER NOT NULL,
    geometry GEOMETRY,
    CONSTRAINT pk_stop PRIMARY KEY (i_stop_id)
    );"
  )

}

# 3-Ecrire les données de l'environnement R vers les 3 tables ----

{
  ## Envoi de mesure_gps
  DBI::dbWriteTable(
    pg_con, #nom de la connexion
    name = "mesure_gps", #nom de la table à créer dans la DB
    value = mesure_gps,  #nom du dataframe de l'environnement R à écrire
    row.names = FALSE,  #ne pas créer de rownames
    append = TRUE, #ajouter les données à la table existante
    overwrite = FALSE, #ne pas écraser la table
    temporary = FALSE
  )
  
  ## Envoi de move_mbgp
  DBI::dbWriteTable(
    pg_con, 
    name = "move", 
    value = move_mbgp, 
    append = TRUE, 
    row.names = FALSE, 
    overwrite = FALSE, 
    temporary = FALSE
  )
  
  ## Envoi de stop_mbgp
  DBI::dbWriteTable(
    pg_con, 
    name = "stop", 
    value = stop_mbgp, 
    append = TRUE, 
    row.names = FALSE, 
    overwrite = FALSE, 
    temporary = FALSE
  )
}

# 4-Requêtes à envoyer dans la table pour corriger les géométries

## Pour certains objets de moves et des stops, la géométrie n'est pas associée au système de coordonnées
## Lambert 93 ; il faut corriger cette erreurs.
## dans un second temps, il faut passer chaque table en WGS84, de code EPSG 4326.

{
  ## Affecter la projection à move
  DBI::dbSendQuery(
    pg_con, 
    "UPDATE move
    SET geometry = ST_SetSRID(geometry, 2154)
    WHERE ST_SRID(geometry) = 0;"
  )
  
  ## Affecter la projection à stop
  DBI::dbSendQuery(
    pg_con, 
    "UPDATE stop
    SET geometry = ST_SetSRID(geometry, 2154)
    WHERE ST_SRID(geometry) = 0;"
  )
  
}

{
  ## Conversion de mesure_gps
  DBI::dbSendQuery(
    pg_con, 
    "UPDATE mesure_gps
    SET geometry = ST_Transform(geometry, 4326);"
  )
  
  ## Conversion de move
  DBI::dbSendQuery(
    pg_con, 
    "UPDATE move
    SET geometry = ST_Transform(geometry, 4326);"
  )

  ### Conversion de stop
  DBI::dbSendQuery(
    pg_con, 
    "UPDATE stop
    SET geometry = ST_Transform(geometry, 4326);"
  )
  
}

### Pensez à vous déconnecter de la BD :
dbDisconnect(pg_con)
### vider l'environnement de R
remove(list=ls())
