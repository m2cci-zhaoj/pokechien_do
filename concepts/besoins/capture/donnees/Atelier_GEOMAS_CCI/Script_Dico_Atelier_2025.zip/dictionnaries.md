## Tables et dictionnaire des variables (Fichiers GEOMAS / CCI)

Les jeux de données partagés se composent de 6 tables :

-   Table brute des points GPS - `mesure_gps_2025` contient l'ensemble des points GPS capturés pendant la semaine de collecte

-   Tables issues de la segmentation des points GPS : `move_mbgp_2025` - elle contient l'ensemble des POLYLIGNES constituant chaque SEGMENT détecté entre 2 arrêts (les stops). Rappel : elle n'est pas enrichie sémantiquement (on ne connaît pas le mode de transport associé à un segment).\
    `stop_mbgp_2025` - elle contient l'ensemble des POINTS constituant chaque arrêt détecté (Un arrêt peut tout aussi bien être le lieu de travail fréquenté pendant plusieurs heures continues que le feu rouge sur la route pendant quelques dizaines de secondes).

    *NB - le suffixe `mbgp` correspond au nom de l'algorithme utilisé pour segmenter les traces GPS.*

-   Tables issues d'un support de capture papier, le carnet de bord (activités/déplacements/poi) : `carnet_deplacement` - ensemble des déplacements déclarés par le participant pendant une semaine de collecte (attention, un déplacement peut inclure des moves et des stops issus de la segmentation et différents modes de transport) - elle renseigne les modes des transports utilisés (y compris s'il s'agit des déplacements de loisirs), la durée des déplacements et les accompagnants éventuels.\
    `carnet_activite` - ensemble des activités déclarées dans différents lieux fréquentés pendant la semaine de collecte (domicile, travail, courses, loisirs, etc.)\
    `carnet_poi` - ensemble des POI fréquentés par le participant (un POI est un lieu fréquenté plus d'une fois dans la semaine de collecte).

Dans les données partagées, il y a un SEUL carnet de mobilité et TROIS traces GPS brutes et segmentées.

### Table des points GPS bruts `mesure_gps`

| Nom du champ | Type du champ            | Description                                         |
|---------------------|---------------------------|------------------------|
| i_pid        | bigint                   | Identifiant unique du point GPS NON NULL PK         |
| i_id_pers    | smallint                 | Numéro du participant                               |
| i_id_session | smallint                 | Numéro de session de collecte                       |
| dt_date_utc  | timestamp with time zone | Timestamp de capture du point GPS (UTC)             |
| r_lat        | double precision         | Latitude du point WGS84 (4326)                      |
| r_long       | double precision         | Longitude du point WGS84 (4326)                     |
| geometry     | geometry                 | Géométrie de la table (POINTS), en Lambert93 (2154) |

### Table 1 issue de la segmentation `move_mbgp`

| Nom du champ | Type du champ | Description                                             |
|---------------------|---------------------------|------------------------|
| i_move_id    | integer       | Identifiant unique du déplacement NON NULL PK           |
| i_pid_start  | integer       | Identifiant du premier point gps du move                |
| i_pid_end    | integer       | Identifiant du dernier point gps du move                |
| geometry     | geometry      | Géométrie de la table (POLYLIGNES), en Lambert93 (2154) |

En calculant la distance d'un *move* puis sa durée, vous pourrez en dériver la vitesse.

### Table issue de la segmentation `stop_mbgp`

| Nom du champ | Type du champ | Description                                        |
|---------------------|---------------------------|------------------------|
| i_stop_id    | integer       | Identifiant unique de l'arrêt NON NULL PK          |
| i_pid_start  | integer       | Identifiant du premier point gps inclus au stop    |
| i_pid_end    | integer       | Identifiant du dernier point gps inclus au stop    |
| geometry     | geometry      | Géométrie de la table (POINTS) en Lambert93 (2154) |

*Idem*, vous pouvez calculer la durée d'un *stop*.

### Table `carnet_deplacement`

**⚠️ Important ⚠️ -** Dans le carnet de mobilité, les identifiants de session (`i_id_session`) et de participants (`i_id_pers`) sont combinés dans le champ `i_id_pers_session`.

Exemple : pour la valeur *i_id_pers_session* = 80, cela signifie la session 0 du participant 8 (le chiffre le plus à droite correspond donc à la session et tous les autres chiffres à gauche correpondent à la personne).

| Nom du champ      | Type du champ            | Description                                                                                                             |
|---------------------|---------------------------|------------------------|
| i_id_carnet_d     | integer                  | Identifiant unique du déplacement NON NULL PK                                                                           |
| i_jour_collecte   | smallint                 | Jour de collecte des données de 1 à N                                                                                   |
| i_id_dep_jour     | smallint                 | Rang du déplacement pour chaque jour de collecte                                                                        |
| i_id_pers_session | smallint                 | Identifiant combiné du participant                                                                                      |
| dt_start_dep_utc  | timestamp with time zone | Timestamp du début de déplacement (UTC)                                                                                 |
| dt_end_dep_utc    | timestamp with time zone | Timestamp de fin du déplacement (UTC)                                                                                   |
| i_duree_secs      | integer                  | Durée du déplacement (secondes)                                                                                         |
| s_code_dep        | varchar(20)              | Mode(s) de déplacement *(séparés par ; si multiples)*                                                                   |
| s_dep_loisir      | varchar(15)              | Indique si le déplacement est lié àla pratique d'une activité de loisirs (course, balade, randonnée)                    |
| i_enf_menage      | smallint                 | Nombre d'enfants du ménage accompagnant                                                                                 |
| i_enf_autre       | smallint                 | Nombre d'enfants hors ménage accompagnant                                                                               |
| i_adul_menage     | smallint                 | Adulte du ménage accompagnant                                                                                           |
| i_adul_autre      | smallint                 | Nombre d'adultes hors ménage accompagnant                                                                               |
| b_false_ts_row    | boolean                  | Détecte les incohérences temporelles sur la ligne i (T si dt_end_dep_utc \< dt_start_dep_utc)                           |
| b_false_ts_lead   | boolean                  | Détecte les incohérences temporelles entre la ligne i et la ligne i+1 (T si dt_end_dep_utc[i] \> dt_start_dep_utc[i+1]) |

### Table `carnet_activite`

| Nom du champ      | Type du champ            | Description                                                                                                             |
|---------------------|---------------------------|------------------------|
| i_id_carnet_a     | integer                  | Identifiant unique de l'activité NON NULL PK                                                                            |
| i_jour_collecte   | smallint                 | Jour de collecte des données de 1 à N                                                                                   |
| i_id_act_jour     | smallint                 | Rang de l'activité pratiquée pour chaque jour de collecte                                                               |
| i_id_pers_session | smallint                 | Identifiant combiné du participant et de sa session                                                                     |
| dt_start_act_utc  | timestamp with time zone | Timestamp du début de l'activité (UTC)                                                                                  |
| dt_end_act_utc    | timestamp with time zone | Timestamp de fin de l'activité (UTC)                                                                                    |
| i_duree_secs      | real                     | Durée de l'activité pratiquée (secondes)                                                                                |
| s_code_act        | varchar(15)              | Code identifiant le type d'activité pratiquée                                                                           |
| s_code_poi        | character(1)             | Lettre identifiant le POI                                                                                               |
| s_non_poi         | text                     | Identifier un lieu fréquenté mais non POI                                                                               |
| b_false_ts_row    | boolean                  | Détecte les incohérences temporelles sur la ligne i (T si dt_end_act_utc \< dt_start_act_utc)                           |
| b_false_ts_lead   | boolean                  | Détecte les incohérences temporelles entre la ligne i et la ligne i+1 (T si dt_end_act_utc[i] \> dt_start_act_utc[i+1]) |

### Table `carnet_poi`

| Nom du champ      | Type du champ | Description                                         |
|---------------------|---------------------------|------------------------|
| i_id_poi          | smallint      | Identifiant unique du POI NON NULL                  |
| i_id_pers_session | smallint      | Identifiant combiné du participant et de sa session |
| s_code_poi        | character(1)  | Lettre identifiant le POI                           |
| s_code_act        | varchar(50)   | Code identifiant de l'activité pratiquée            |
| s_nom_poi         | varchar(50)   | Nom du POI                                          |
| i_num_rue         | smallint      | Numéro de la rue                                    |
| s_nom_rue         | varchar(50)   | Nom de la rue                                       |
| i_code_postal     | integer       | Code postal                                         |
| s_nom_com         | varchar(30)   | Nom de la commune                                   |
| s_information     | text          | Autres informations de localisation                 |
| s_obs_enq         | text          | Observations de l'enquêteur                         |
| s_obs_saisie      | text          | Observations lors de la saisie                      |

Pour terminer, voici le sens des abréviations utilisées pour les modes de transport :

-   map = marche à pied

-   tram = tramway ;

-   vpp = voiture personnelle (passager)

-   vpc = voiture personnelle (conducteur)

Et pour les codes des activités exercées dans le carnet :

-   1 = domicile personnel (quelle que soit l'activité exercée) ;

-   2 = travail sur lieu habituel

-   4 = achats divers en magasin

-   5 = services divers à la personne

-   7 = santé

-   9 = marche sportive, course, randonnée

-   10 = promenade, balade, lèche-vitrine en ville

-   16 = sociabilités et visites à la famille
